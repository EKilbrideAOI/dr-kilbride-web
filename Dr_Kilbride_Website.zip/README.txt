DR. EARL KILBRIDE — PREMIUM STATIC WEBSITE

Open index.html to preview the site.

Included:
- Premium physician/medical design
- Uploaded Dr. Kilbride portrait integrated into hero/about sections
- AOI/business-card assets
- Trauma, fractures, joint replacement/reconstruction, sports medicine,
  auto accident, workers' compensation, PRP, PNS and LOP service sections
- Georgetown and North Austin locations
- Click-to-call scheduling
- Mobile responsive layout
- SEO title and description

Before publishing, verify all clinical/service, insurance, LOP, scheduling,
address and marketing language with the practice/compliance team.

The current location and professional biography details were checked against
Austin Orthopedic Institute's public provider page on 2026-09-24.
